# Warband Ages

Original real-time army strategy game for Android, inspired by the genre of
"We Are Warriors!" (two bases, food economy, summon units, evolve through ages).
All art is drawn from code and all audio is synthesised at start-up, so the
project contains **no copied or external assets**.

Engine: **Godot 4.3** (GL Compatibility renderer, GDScript). Landscape, immersive full screen.

## Get the APK (no local tools needed)

1. Create a new GitHub repository.
2. Upload this project (either unzip and push the folders, **or** simply upload
   `WarbandAges-project.zip` renamed to `game.zip` into the repo root).
3. Add the workflow file `.github/workflows/build-apk.yml` (included in the zip;
   on GitHub web use *Add file > Create new file* and type the path).
4. Open the **Actions** tab -> *Build Android APK* -> *Run workflow*.
5. When it finishes, download the artifact **WarbandAges-apk** -> `WarbandAges.apk`.
6. Copy it to your phone and install (allow "Install unknown apps" for your file manager/browser).

The APK is signed with a throw-away debug key (fine for personal use, not for Play Store).
Target: arm64-v8a (all modern Android phones).

## Build locally

1. Install Godot 4.3 + export templates, Android SDK (build-tools 34, platform 34) and JDK 17.
2. In Godot: *Editor Settings > Export > Android* set SDK path, JDK path and debug keystore.
3. Open `project.godot`, then *Project > Export > Android > Export Project* (debug),
   or headless: `godot --headless --import && godot --headless --export-debug Android build/WarbandAges.apk`

## Features

* 5 ages (Stone, Iron, Medieval, Industrial, Modern), 5 units each (25 unique sprites/vehicles).
* Food economy (time-based, capacity, upgrades), XP-based age evolution that changes unit roster,
  base art, backdrop, food income and capacity.
* Enemy AI (counter-picking, saving for elites, danger response, scheduled waves, evolution schedule).
* 20-level campaign in 4 chapters, stars, locked/unlocked levels, rewards granted once.
* 6 permanent upgrades (food rate, capacity, base HP, damage, health, cost reduction).
* Pause / restart / settings / menu, victory & defeat panels, retry, next level.
* Save file (atomic write, validated on load), sound + music toggles and volumes.
* Touch: tap or hold unit cards (multi-touch), Android back button, auto-pause on focus loss.
* Fixed 60 Hz simulation step => identical gameplay at any frame rate.

## Status (honest)

This project was written without access to a Godot/Android toolchain, so it has **not been compiled,
run, balanced or tested on a device**. Only static checks (bracket balance, indentation) were done.
Expect to fix a few GDScript errors/bugs on first run; the Godot editor output points to exact lines.
